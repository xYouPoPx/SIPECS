<!DOCTYPE html>
<html>
<head>

<meta charset="utf-8" />

<title>SIPECS - Tableau de bord</title>



<link href="styles.css" rel="stylesheet" />

</head>

<body>

	<header>

		<a id="logo" href="http://www.collegeshawinigan.ca/"></a>

		<div>
			<h1>Tableau de bord</h1>
		</div>

	</header>

<?php
ini_set ( 'display_errors', 1 );
session_start ();
function affMenu() { // affiche les menus disponible pour la personne connecté
	echo '<div class="clear"></div>
	
		<nav>

		<ul>

			<!-- <li><a href="#">Technique de Génie Mécanique<br />241.A0</a></li> -->

			<li><a href="#">Science de la nature<br />200.B0</a></li>

		</ul>

		</nav>
	
		<div class="title">

			<h1>Cheminement des étudiants en Science de la nature 200.B0</h1>

		</div>
		
		<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		Division de contenu
		- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  -->
		
		<div class="content">
			 <img class="report" src="reports/nombre_init_inscrit_population.png" alt="test resport" height="410" width="576"> 
		</div>
		
		<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		Division pour indiquer la légende
		- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  -->

		<div id="legend">
			<div class="btnTabBord">
				<a href="#" class="btnTabBord"> <&nbsp;Tableau de Bord</a>
			</div>
			<h6>Légende</h6>
			<p>Tendance comparée à la cohorte précédente</p>
			<p class="texte"><span class="up"></span> Hausse <span class="down"></span> Baisse <span class="stable"></span> Stable</p>
			<p>Nombre de cours écueils</p>
			<p class="texte"><span class="null"></span> Aucun <span class="warning"></span> À surveiller</p>
		</div>';
}
function formConnection() {
	echo '	<div id="login">

		<h3>Connexion</h3>

			<form method="post" action="#" name="form_login">

				<p><input type="text" id="sipecs_no_employe" name="sipecs_no_employe" value="" placeholder="No d\'employé" required ></p>

				<p><input type="password" id="sipecs_mot_de_passe" name="sipecs_mot_de_passe" value="" placeholder="Mot de passe" required ></p>

				<p><input type="submit" name="commit" value="Connexion" class="submit"></p>

			</form>

		</div>';
}

if (isset ( $_SESSION ['idsipecs_user'] )) { // si la session est déja créé
	
	affMenu (); // affiche les infos d'un utilisateur connecté
} 

elseif (isset ( $_POST ['sipecs_no_employe'] ) and isset ( $_POST ['sipecs_mot_de_passe'] ))/* si les données sont posté depuis le formulaire de login*/
		{
	
	if (empty ( $_POST ['sipecs_no_employe'] ) or empty ( $_POST ['sipecs_no_employe'] )) {
		
		echo '<script>
							alert("Ne pas laisser de champs vide");
						</script>';
		
		formConnection ();
	} 

	else {
		
		include ('connection/bdlogin.php'); /* connection a la table */
		
		// $pass_hache = sha256($_POST['mdp']);
		
		// on selectionne les informations de la table utilisateur (sipecs_user)
		$req = $bdd->prepare ( 'SELECT * FROM sipecs_user WHERE sipecs_no_employe = :sipecs_no_employe AND sipecs_mot_de_passe = :mot_de_passe' );
		$req->execute ( array (
				'sipecs_no_employe' => $_POST ['sipecs_no_employe'],
				'mot_de_passe' => $_POST ['sipecs_mot_de_passe'] 
		) );
		
		$resultat = $req->fetch ();
		
		if (! $resultat)/*si aucun resultat le nom ou mot de passe est pas bon*/
						{
			echo '<script>
									alert("Mauvais numero d\'employé ou mot de passe");
								</script>';
			formConnection ();
		} else {
			if ($resultat ['sipecs_status'] == '0') /*si le mot de passe a jamais ete changé ouvre le formulaire de changement*/
								{
				echo '<script>
													alert("Vous devez inscrire un nouveau mot de passe");
											</script>';
				echo '<div id="login">

									<h3>Première connexion</h3>

									<form method="post" action="change.php" name="form_change">

										<p><input type="password" id="mot_de_passe1" name="mot_de_passe1" value="" placeholder="Nouveau mot de passe" required ></p>

										<p><input type="password" id="mot_de_passe2" name="mot_de_passe2" value="" placeholder="Confirmez le mot de passe" required ></p>
										<input type="hidden" name="idsipecs_user" value="' . $resultat ['idsipecs_user'] . '"/>

										<p><input type="submit" name="commit" value="Envoyer" class="submit"></p>

									</form>

								</div>';
			} else /* ouverture des variables de session */
{
				
				$_SESSION ['idsipecs_user'] = $resultat ['idsipecs_user'];
				$_SESSION ['sipecs_user_nom'] = $resultat ['sipecs_user_nom'];
				$_SESSION ['sipecs_user_prenom'] = $resultat ['sipecs_user_prenom'];
				
				affMenu ();
			}
		}
	}
} 

else // si aucune session et aucun post de fait affiche le formulaire de connection
{
	
	formConnection ();
}

echo '<div class="clear"></div>';

if (isset ( $_SESSION ['idsipecs_user'] )) // si l'utilisateur est connecté on affiche le bas de la page
{
	echo '<footer>
					<a href="deco.php"><img src="img/logout.png" class="logout" alt="Déconnexion"/></a> 
					<p>' . $_SESSION ['sipecs_user_prenom'] . ' ' . $_SESSION ['sipecs_user_nom'] . '</p>
			</footer>';
}
?>


	<div class="clear"></div>

</body>

</html>
