<?php
	if(isset($_POST['mot_de_passe1']) AND isset($_POST['mot_de_passe2']) AND isset($_POST['idsipecs_user']))
		{
			
			if($_POST['mot_de_passe1'] !=  $_POST['mot_de_passe2'])
				{
					echo'<script>
							alert("Les mots de passe ne sont pas identiques");
						</script>';
						include('index.php');
				
				}
			else
				{
				
				

					include('connection/bdlogin.php');
				
						//$pass_hache = sha1($_POST['mot_de_passe1']);
					$req = $bdd->prepare('UPDATE sipecs_user SET sipecs_mot_de_passe = :sipecs_mot_de_passe,  sipecs_status = 0 WHERE idsipecs_user = :idsipecs_user ');
						$req->execute(array(
							'idsipecs_user' => $_POST['idsipecs_user'],
							'sipecs_mot_de_passe' => $_POST['mot_de_passe1']));
					
								echo '<script>
								alert("Le mot de passe a ete changé, veuillez vous reconnecter");
								</script>';
					include('index.php');
				}
				
		}
	else
	{
		include('index.php');
	}
?>