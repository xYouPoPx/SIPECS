<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>SIPECS - Tableau de bord</title>

	<link href="styles.css" rel="stylesheet" />
</head>

<body>
	<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	Entête du site Web
	Il n'y a aucune modification à faire
	Sauf peut-être changer le titre Tableau de bord pour Connexion, au départ?
	- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  -->
	<header>
		<a id="logo" href="http://www.collegeshawinigan.ca/"></a>
		<div>Tableau de bord</div>
	</header>

	<!--
	Div important. C'est un clear both. (pour les divs flottant du haut)
	-->
	<div class="clear"></div>

	<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	Navigation
	- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  -->

	<!--
	<nav>
		<ul>
			<li><a href="#">Technique de Génie Mécanique<br />241.A0</a></li>
			<li><a href="#">Science de la nature<br />200.B0</a></li>
		</ul>
	</nav>
	-->

	<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	Titre "Cheminement des étudiants en {Insérez le nom du programme ici}"
	- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  -->
	<!--
	<div class="title">
		<h1>Cheminement des étudiants en {Insérez le nom du programme ici}</h1>
	</div>
	-->

	<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	Division de contenu
	- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  -->

	<!--
	<div class="content">
	</div>
	-->

	<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	Division pour la page connexion
	- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  -->

	<div id="login">
		<h3>Connexion</h3>
		<form method="post" action="index.php">
			<p><input type="text" name="login" value="" size="30" placeholder="No d'employé"></p>
       		<p><input type="password" name="password" value="" size="30" placeholder="Mot de passe"></p>

       	 	<p><input type="submit" name="commit" value="Connexion" class="submit"></p>
		</form>
	</div>


	<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	Division pour indiquer la légende
	- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  -->

	<!--
	<div id="legend">
		<h6>Légende</h6>

		<p>Tendance comparée à la cohorte précédente</p>
		<p class="texte"><span class="up"></span> Hausse <span class="down"></span> Baisse <span class="stable"></span> Stable</p>

		<p>Nombre de cours écueils</p>
		<p class="texte"><span class="null"></span> Aucun <span class="warning"></span> À surveiller</p>
	</div>
	-->

	<!--
	Div important. C'est un clear both. (pour les divs flottant du haut)
	-->
	<div class="clear"></div>

	<!-- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	Pied de page
	- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  -->
	<footer>
		<a href="#"><img src="img/logout.png" class="logout" alt="Déconnexion"/></a>
	</footer>

	<!--
	Div important. C'est un clear both. (pour les divs flottant du haut)
	-->
	<div class="clear"></div>
</body>

</html>
