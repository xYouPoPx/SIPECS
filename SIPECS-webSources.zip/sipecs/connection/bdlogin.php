<?php
try
{
	$bdd = new PDO('mysql:host=localhost;dbname=yolaine_sipecs', 'yolaine_sipecs', 'sipecs');
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}
?>