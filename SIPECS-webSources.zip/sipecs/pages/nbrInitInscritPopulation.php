<p><br />
	<img class="report" src="reports/nombre_init_inscrit_population.png" alt="test resport" height="410" width="576"> 
</p>
<p class="rapportDescription">
Précise le nombre total d’étudiants inscrits à leur première session dans le programme et dont c’est la première inscription à vie dans ce programme. Un étudiant est considéré inscrit dans un programme qu’il soit à temps complet ou à temps partiel. Le nombre initial d’inscrits constitue l’effectif de départ de la cohorte. Il s’agit d’une donnée importante, puisque c’est en référence à celle-ci que seront souvent calculés d’autres indicateurs
</p>