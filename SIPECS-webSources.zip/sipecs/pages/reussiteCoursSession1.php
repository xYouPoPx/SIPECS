<p><br />
	<img class="report" src="reports/reussite_cours_session_1.png" alt="test resport" height="410" width="576"> 
</p>
<p class="rapportDescription">
Le taux de réussite moyen des cours à la première session est calculé à partir du taux de réussite individuel. Ce dernier correspond à la proportion de cours réussis par rapport à ceux auxquels chaque étudiant était inscrit. Par exemple, le taux de réussite individuel d’un étudiant sera de 75% s’il a réussi 6 des 8 cours auxquels il était inscrit. Le tau de réussite moyen correspond à la somme des taux de réussite individuels d’une cohorte donnée divisée par le nombre total d’étudiants de cette cohorte.
</p>