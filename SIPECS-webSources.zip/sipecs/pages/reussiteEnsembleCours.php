<p><br />
	<img class="report" src="reports/reussite_ensemble_cours.png" alt="test resport" height="410" width="576"> 
</p>
<p><br />
	<img class="report" src="reports/reussite_ensemble_cours_tab.png" alt="test resport" > 
</p>
<p class="rapportDescription">
Le calcul du taux de réussite de l’ensemble des cours consiste à diviser la somme des taux de réussite individuels par le nombre d’étudiants inscrits, le résultat étant exprimé en pourcentage, d’une part, pour les cours de la formation générale et, d’autre part, pour les cours de la formation spécifique. Le taux de réussite de l’ensemble des cours est fourni selon la cohorte et est rendu disponible dans e mesure où l’ensemble des cours prévus à la grille des cours ont été donnés.
</p>