<?php
echo '<div id="container">
	<div class="linkScoreCard">
		<a href="index.php?prog=' . $_GET ['prog'] . '&page=nbrInitInscritPopulation">
			<div id="left">
				<div class="column-in">
					<p id="lccont">Nombre initial d\'inscrits dans la cohorte</p>
				</div>
			</div>

			<div id="middle">
				<div class="column-in">
					<p id="mccont">99 %</p>
				</div>
			</div>

			<div id="right">
				<div class="column-in">
					<p>
						<img src="img/up.png" alt="tendance" />
					</p>
				</div>
			</div> <!--  <div class="cleaner">&nbsp;</div> -->
		</a>
	</div>
<div class="linkScoreCard">
		<a href="index.php?prog=' . $_GET ['prog'] . '&page=reussiteCoursSession1">
			<div id="left">
				<div class="column-in">
					<p id="lccont">Réussite des cours à la première session</p>
				</div>
			</div>

			<div id="middle">
				<div class="column-in">
					<p id="mccont">99 %</p>
				</div>
			</div>

			<div id="right">
				<div class="column-in">
					<p>
						<img src="img/up.png" alt="tendance" />
					</p>
				</div>
			</div> <!--  <div class="cleaner">&nbsp;</div> -->
		</a>
	</div>

<div class="linkScoreCard">
		<a href="index.php?prog=' . $_GET ['prog'] . '&page=reussiteEnsembleCours">
			<div id="left">
				<div class="column-in">
					<p id="lccont">Réussite de l\'ensemble des cours</p>
				</div>
			</div>

			<div id="middle">
				<div class="column-in">
					<p id="mccont">99 %</p>
				</div>
			</div>

			<div id="right">
				<div class="column-in">
					<p>
						<img src="img/up.png" alt="tendance" />
					</p>
				</div>
			</div> <!--  <div class="cleaner">&nbsp;</div> -->
		</a>
	</div>
</div>';
