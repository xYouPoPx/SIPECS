<!DOCTYPE html> 
<html>
<head>

	<meta charset="utf-8" />

	<title>SIPECS - Tableau de bord</title>



	<link href="styles.css" rel="stylesheet" />

</head>


<?php

function affTitre(){
	
	if(isset($_GET['page'])){
		
			switch($_GET['page']){
				case 'scorecard':
							$titre = 'Tableau de bord';
							break;
						case 'nbrInitInscritPopulation':
							$titre = 'Nombre initial d’inscrits';
							break;
						case 'reussiteCoursSession1':
							$titre ='Réussite des cours à la première session';
							break;
						case 'reussiteEnsembleCours':
							$titre = 'Réussite de l’ensemble des cours';
							break;
						default:
						$titre = 'Tableau de bord';
						break;
					}
				
			}
	else{
		$titre = ' ';
	}
	
			
	echo'
	<div class="title">

			<h1>'.$titre.'</h1>

		</div>';
		
}


function affLegende(){
	
echo'
		
		<div id="legend">
		';
		
		if(isset($_GET['prog'])){
			echo'<div class="btnTabBord">
			<a href="index.php?prog='.$_GET['prog'].'&page=scorecard" class="btnTabBord">&#60;&nbsp;&nbsp;&nbsp;Tableau de Bord</a>
		</div>
			';
		}

		echo'
		<h6>Légende</h6>

		<p>Tendance comparée à la cohorte précédente</p>

		<p class="texte"><span class="up"></span> Hausse <span class="down"></span> Baisse <span class="stable"></span> Stable</p>



		<p>Nombre de cours écueils</p>

		<p class="texte"><span class="null"></span> Aucun <span class="warning"></span> À surveiller</p>

	</div>';
}

function affMenu(){ //affiche les menus disponible pour la personne connecté
	include('connection/bdlogin.php'); /*connection a la table*/
	$req = $bdd->prepare('SELECT user.sipecs_dim_programme_id, prog.IDProgramme, prog.TitreCourt, prog.TitreLong, prog.Numero FROM sipecs_user_programme user 
							
							INNER JOIN dim_programme prog ON user.sipecs_dim_programme_id = prog.IDProgramme
							
							WHERE sipecs_user_id = :sipecs_user_id
							');
				$req->execute(array(
					'sipecs_user_id' => $_SESSION['idsipecs_user'])); 

					echo'<div class="clear"></div>
	
						<nav>

							<ul>';
					
								while($resultat = $req->fetch())
								{
									
									echo'<li><a href="index.php?prog='.$resultat['sipecs_dim_programme_id'].'&page=scorecard">'.$resultat['TitreCourt'].'<br />'.$resultat['Numero'].'</a></li>';
									
								}
				
echo'
		</ul>

		</nav>';
		
		if(isset($_GET['prog'])){
			affTitre();
			echo'<div class="content">';
				if(isset($_GET['page'])){
					switch($_GET['page']){
						
						case 'scorecard':
							include('pages/scorecard.php');
							break;
						case 'nbrInitInscritPopulation':
							include('pages/nbrInitInscritPopulation.php');
							break;
						case 'reussiteCoursSession1':
							include('pages/reussiteCoursSession1.php');	
							break;
						case 'reussiteEnsembleCours':
							include('pages/reussiteEnsembleCours.php');
							break;
						default:
						include('pages/scorecard.php');
						break;
					}
					
				}
				else{
					include('pages/scorecard.php');
				}
			echo'</div>';
			
			affLegende();
		}
		else{
			affLegende();

			affTitre();
		}
	
			
	
	
}
function formConnection(){
echo '	<div id="login">

		<h3>Connexion</h3>

			<form method="post" action="#" name="form_login">

				<p><input type="text" id="sipecs_no_employe" name="sipecs_no_employe" value="" placeholder="No d\'employé" required ></p>

				<p><input type="password" id="sipecs_mot_de_passe" name="sipecs_mot_de_passe" value="" placeholder="Mot de passe" required ></p>

				<p><input type="submit" name="commit" value="Connexion" class="submit"></p>

			</form>

		</div>';
}

echo'<body>';

ini_set('display_errors', 1);
session_start();
include('connection/bdlogin.php'); /*connection a la table*/

if(isset($_GET['prog'])){
		$req = $bdd->prepare('SELECT TitreLong FROM dim_programme WHERE IDProgramme = :idprog');
		
	
	$req->execute(array(
					'idprog' => $_GET['prog'])); 
					
				$resultat = $req->fetch();	
	echo'

			<header>

		<a id="logo" href="http://www.collegeshawinigan.ca/"></a>

		
		
		<div><h1>'.$resultat['TitreLong'].'</h1></div>

	</header>';
	}
	else
	{
		echo'	<header>

		<a id="logo" href="http://www.collegeshawinigan.ca/"></a>

		
		
		<div><h1>Tableau de bord</h1></div>

	</header>';
	}


	if(isset($_SESSION['idsipecs_user']))
		{ // si la session est déja créé
		
			affMenu(); // affiche les infos d'un utilisateur connecté
			
		}
		
		

	elseif(isset($_POST['sipecs_no_employe']) AND isset($_POST['sipecs_mot_de_passe']))/* si les données sont posté depuis le formulaire de login*/
		{
			
			if(empty($_POST['sipecs_no_employe']) OR empty($_POST['sipecs_no_employe']))
				{
				
					echo'<script>
							alert("Ne pas laisser de champs vide");
						</script>';
					
					formConnection();
				
				}
			
			else{
					
				include('connection/bdlogin.php'); /*connection a la table*/
					//$pass_hache = sha256($_POST['mdp']);
			
				//on selectionne les informations de la table utilisateur (sipecs_user)
				$req = $bdd->prepare('SELECT * FROM sipecs_user WHERE sipecs_no_employe = :sipecs_no_employe AND sipecs_mot_de_passe = :mot_de_passe');
				$req->execute(array(
					'sipecs_no_employe' => $_POST['sipecs_no_employe'],
						'mot_de_passe' => $_POST['sipecs_mot_de_passe'])); 

				$resultat = $req->fetch();

					if (!$resultat)/*si aucun resultat le nom ou mot de passe est pas bon*/
						{
							echo'<script>
									alert("Mauvais numero d\'employé ou mot de passe");
								</script>';
							formConnection();
						
						}	
					else
						{
							if($resultat['sipecs_status'] == '0') /*si le mot de passe a jamais ete changé ouvre le formulaire de changement*/
								{
										echo'<script>
													alert("Vous devez inscrire un nouveau mot de passe");
											</script>';
										echo'<div id="login">

									<h3>Première connexion</h3>

									<form method="post" action="change.php" name="form_change">

										<p><input type="password" id="mot_de_passe1" name="mot_de_passe1" value="" placeholder="Nouveau mot de passe" required ></p>

										<p><input type="password" id="mot_de_passe2" name="mot_de_passe2" value="" placeholder="Confirmez le mot de passe" required ></p>
										<input type="hidden" name="idsipecs_user" value="'.$resultat['idsipecs_user'].'"/>

										<p><input type="submit" name="commit" value="Envoyer" class="submit"></p>

									</form>

								</div>';
								}
							else /*ouverture des variables de session*/
								{	
						
							$_SESSION['idsipecs_user'] = $resultat['idsipecs_user'];
							$_SESSION['sipecs_user_nom'] = $resultat['sipecs_user_nom'];
							$_SESSION['sipecs_user_prenom'] = $resultat['sipecs_user_prenom'];
							
							affMenu();
							
								}
	
						}
					
			}
		}

	else // si aucune session et aucun post de fait affiche le formulaire de connection
		{

			formConnection();
			
		}



	echo'<div class="clear"></div>';



	
if(isset($_SESSION['idsipecs_user'])) // si l'utilisateur est connecté on affiche le bas de la page
	{
		echo'<footer>
					<a href="deco.php"><img src="img/logout.png" class="logout" alt="Déconnexion"/></a> 
					<p>'.$_SESSION['sipecs_user_prenom'].' '.$_SESSION['sipecs_user_nom'].'</p>
			</footer>';
	}
?>


	<div class="clear"></div>

</body>

</html>
